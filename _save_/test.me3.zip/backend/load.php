<?php

require "connect.php";

$pdo = new ConnectDatabase(constant("HOST"), constant("USER"), constant("PASSWORD"), constant("DATABASE"));

$myJSON = null;

if (isset($_GET['actualrow']) && isset($_GET['loadstep'])) {
    $actualrow = $_GET['actualrow'];
    $loadstep = $_GET['loadstep'];
    $loadend = $actualrow + $loadstep;

    $stmt = $pdo->conn->prepare("SELECT * FROM news WHERE sequence >= ? AND sequence <= ? ");
    
    $stmt->bindParam(1, $actualrow);
    $stmt->bindParam(2, $loadend);
    $stmt->execute();
    $data = $stmt->fetchAll();
    
    $dataSave = [];
    
    foreach ($data as $row) {
        array_push($dataSave, ['id' => $row['id'], 'sequence' => $row['sequence'], 'title' => $row['title'],  'text' => $row['text']]);
    }
    
    $myJSON = json_encode($dataSave);
}

echo $myJSON;
?>